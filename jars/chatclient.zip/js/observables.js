// Observer & Observable

function Publisher() { 		/// Object
	
	this.listeners = null; 	// Needs override...
	
	this.addChangeListener = addChangeListener;
	this.notifyListeners = notifyListeners;	
}


function addChangeListener(obj) {
	this.listeners[this.listeners.length] = obj;
}

function notifyListeners() {	
	for(i=0;i<this.listeners.length;i++) {
		this.listeners[i].update(this);
	}
}	