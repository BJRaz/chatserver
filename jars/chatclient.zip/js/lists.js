	/**
	*	Write something...
	*/
	Object.prototype.equals = function(obj) {				
		if(typeof obj == "object") {
			if(this == obj)
				return true;
		}
		return false;
	}
	
	
	/*
	*
	*/
	function ListIterator(list) {
		var list = list;
		var index = 0;
		var currentItem = null;
		
		this.first = function() {
			currentItem = list.elementAt(0);	
		}
		
		this.next = function() {
			if(!this.isDone()) {
				currentItem = list.elementAt(++index);	
			}		
		}
		this.isDone = function() {
			if(index == list.count())
				return true;
			return false;	
		}
		this.item = function() {
			return currentItem;
		}	
		this.reset = function() {
			currentItem = null;
			index = 0;
		}
	}
	
	
	/*
	*	LIST
	*/
	function List() {
		this.listItems = new Array();
		this.listeners = new Array();
		
		this.sort = function() {
			this.listItems.sort();
		}
		
		this.count = function() {
			return this.listItems.length;	
		}	
		
		this.clear = function() {
			this.listItems = new Array();				
			this.notifyListeners();				
		}
		
		this.add = function(obj) {
			this.listItems[this.listItems.length] = obj;	
			this.notifyListeners();
		}
		
		this.remove = function(obj) {
			for(var i=0;i<this.listItems.length;i++) {		
				if(obj.equals(this.listItems[i])) {					
					this.listItems.splice(i, 1);	// removes obj from array
					this.notifyListeners();
					return true;
				}
			}
			return false;
		}
		
		this.elementAt = function(index) {
			try {
				return this.listItems[index];
			} catch(e) {
				throw e;	
			}
		}
		
		this.find = function(obj) {
			for(var i=0;i<this.listItems.length;i++) {
				if(obj.equals(this.listItems[i]))
					return obj;
			}
		}
		
		this.getIterator = function() {
			return new ListIterator(this);	
		}
	}
	
	List.prototype = new Publisher;
	
	
	function User(id, name) {
		this.id = id;
		this.name = name;						
	}
	
	User.prototype.equals = function(obj) {
		if(typeof obj == "object") {
			if(obj.constructor == User) {
				return (obj["id"] == this["id"] && obj["name"] == this["name"]) ? true : false;
			}
		}
	}
	
	
	function UserList() {		// Extends List
		
		function sortUser(a, b) {						
			// localeCompare JS version 1.5			
			return (a["name"]).localeCompare((b["name"]));
		}
	
		this.sort = function() {	
			this.listItems.sort(sortUser);
		}		
		
	}
	
	UserList.prototype = new List;
	
	
	function UserView(model, elm) {
		var model = model;
		model.addChangeListener(this);
		
		var me = this;
		var element = elm;
		
		
		this.html;
		
		function render() {
			var table = document.createElement("TABLE");
			table.border = 0;
			table.cellPadding = 2;
			table.cellSpacing = 0;
			table.className = "userTable";
			
			var tbody = document.createElement("TBODY");
			
			var iter = model.getIterator();
		
			/**
			*	Iterate through Users.
			*/
			for(iter.first();!iter.isDone();iter.next()) {
				tr = document.createElement("TR");
				td = document.createElement("td");
				
				td.id = iter.item()["id"];
				td.name = iter.item()["name"];
				
				td.onclick = function() {
					setAsPrivate(this.id, this.name);	
				}
				
				td.appendChild(document.createTextNode(iter.item()["name"]));
										
				tr.appendChild(td);
				tbody.appendChild(tr);
			}
			table.appendChild(tbody);
			
			if(element.firstChild)
				element.replaceChild(table, element.firstChild);
			else
				element.appendChild(table);
		}	
		
		this.setElement = function(elm) {
			element = elm;	
		}	
		
		this.update = function(obj) {
			model.sort();
			render();	
		}
					
		render();
		
	}
	
	function Message(id, handle, message) {
		this.id = id;
		this.handle = handle;
		this.message = message;		
	}
	
	function PrivateMessage(id, handle, message) {
		this.id = id;
		this.handle = handle;
		this.message = message;
	}
	
	function MessageView(model, elm) {
		
		var model = model;
		model.addChangeListener(this);
		
		var me = this;
		var element = elm;
		
		this.html;
		
		function render() {
			
			var table = document.createElement("TABLE");
			table.border = 0;
			table.cellPadding = 2;
			table.cellSpacing = 0;
			table.className = "messageTableView";
			
			var tbody = document.createElement("TBODY");
			
			table.appendChild(tbody);
			
			if(element.firstChild)
				element.replaceChild(table, element.firstChild);
			else
				element.appendChild(table);
			
			me.html = table;
			
		}
	
		this.update = function(listobj) {
			var tbody = me.html.getElementsByTagName("TBODY");
			tr = document.createElement("TR");
			td = document.createElement("td");
			
			var obj = model.elementAt(model.count() - 1);
			if(obj == null) {
				element.innerHTML = "";
				render();
				return;
			}				
			var text = "[" + obj["handle"] + "] " + obj["message"];
			if(obj.constructor == PrivateMessage)
				td.className = "privateMsg";
			else
				td.className = "publicMsg";
			//td.appendChild(document.createTextNode(text));
			td.innerHTML = text;
			tr.appendChild(td);
			
			tbody.item(0).appendChild(tr);
			tr.scrollIntoView();
			obj = null;
		}
	
		render();
	}