package tfud.communication;

import java.io.Serializable;

public class DataPackage implements Serializable {
	protected int id, targetid;
	protected String handle;
	protected String event;
	protected Object data;	
	/**
	 * Method DataPackage
	 *
	 *
	 */
	public DataPackage() {
		// TODO: Add your code here
		id = 0;
		targetid = 0;
		handle = "";
		event = "";
		data = "";
	}

	public DataPackage(int id, int targetid, String handle, String event, Object data) {
		// TODO: Add your code here
		this.id = id;
		this.targetid = targetid;
		this.handle = handle;
		this.event = event;
		this.data = data;
	}

	/**
	 * Method getID
	 *
	 *
	 * @return
	 *
	 */
	public int getID() {
		// TODO: Add your code here
		return id;
	}

	/**
	 * Method setID
	 *
	 *
	 * @param id
	 *
	 * @return
	 *
	 */
	public void setID(int id) {
		// TODO: Add your code here
		this.id = id;
	}

	/**
	 * Method getHandle
	 *
	 *
	 * @return
	 *
	 */
	public String getHandle() {
		// TODO: Add your code here
		return handle;
	}

	/**
	 * Method setHandle
	 *
	 *
	 * @param handle
	 *
	 */
	public void setHandle(String handle) {
		// TODO: Add your code here
		this.handle = handle;
	}

	/**
	 * Method getEventType
	 *
	 *
	 * @return
	 *
	 */
	public String getEventType() {
		// TODO: Add your code here
		return event;
	}

	/**
	 * Method setEventType
	 *
	 *
	 * @param event
	 *
	 */
	public void setEventType(String event) {
		// TODO: Add your code here
		this.event = event;
	}

	/**
	 * Method getData
	 *
	 *
	 * @return
	 *
	 */
	public Object getData() {
		// TODO: Add your code here
		return data;
	}

	/**
	 * Method setData
	 *
	 *
	 */
	public void setData(Object data) {
		// TODO: Add your code here
		this.data = data;
	}	
	
	
	/**
	 * Method setTargetID
	 *
	 *
	 * @param id
	 *
	 */
	public void setTargetID(int id) {
		// TODO: Add your code here
		this.targetid = id;
	}

	/**
	 * Method getTargetID
	 *
	 *
	 * @return
	 *
	 */
	public int getTargetID() {
		// TODO: Add your code here
		return this.targetid;
	}
	
	public String toString() {
		return "DataPackage[ID: " + this.id + " TargetID: " + this.targetid + " Handle: " + this.handle + " Event: " + this.event + " Data: " + this.data.toString();
	}

}
