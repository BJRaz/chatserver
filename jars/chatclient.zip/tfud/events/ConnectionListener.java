package tfud.events;


public interface ConnectionListener {
	public void connectionUpdated(ConnectionEvent conObj);
}
